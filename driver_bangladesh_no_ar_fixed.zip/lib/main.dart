import 'package:flutter/material.dart';

void main() => runApp(const DriverBangladesh());

class DriverBangladesh extends StatelessWidget {
  const DriverBangladesh({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Driver Bangladesh',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.green), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Driver Bangladesh'), centerTitle: true),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Card(child: Padding(padding: EdgeInsets.all(20), child: Column(children: [
        Icon(Icons.local_taxi, size: 64, color: Colors.green),
        SizedBox(height: 10),
        Text('ড্রাইভার খুঁজুন, চাকরি খুঁজুন', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        SizedBox(height: 8), Text('ড্রাইভার ও গাড়ির মালিকদের জন্য সহজ চাকরি প্ল্যাটফর্ম', textAlign: TextAlign.center),
      ]))),
      const SizedBox(height: 12),
      _button(context, Icons.search, 'চাকরি খুঁজছি', 'ড্রাইভার চাকরির তালিকা দেখুন', const JobsPage()),
      _button(context, Icons.person_add, 'চাকরি দিতে চাই', 'ড্রাইভার নিয়োগের তথ্য দিন', const PostJobPage()),
      _button(context, Icons.info_outline, 'অ্যাপ সম্পর্কে', 'এই ডেমো অ্যাপের তথ্য', const AboutPage()),
    ]),
  );
  Widget _button(BuildContext c, IconData i, String t, String s, Widget p) => Card(child: ListTile(
    leading: Icon(i, color: Colors.green, size: 32), title: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(s), trailing: const Icon(Icons.arrow_forward_ios, size: 18),
    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => p)),
  ));
}

class JobsPage extends StatelessWidget {
  const JobsPage({super.key});
  final jobs = const [
    ['প্রাইভেট গাড়ির ড্রাইভার', 'ঢাকা', '১৫,০০০ - ২০,০০০ টাকা'],
    ['পিকআপ ড্রাইভার', 'উত্তরা', '১৮,০০০ টাকা'],
    ['মাইক্রোবাস ড্রাইভার', 'মিরপুর', '২০,০০০ - ২৫,০০০ টাকা'],
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('চাকরির তালিকা')),
    body: ListView.builder(padding: const EdgeInsets.all(12), itemCount: jobs.length, itemBuilder: (_, i) => Card(child: ListTile(
      leading: const CircleAvatar(child: Icon(Icons.directions_car)), title: Text(jobs[i][0]), subtitle: Text('স্থান: ${jobs[i][1]}\nবেতন: ${jobs[i][2]}'), isThreeLine: true,
      trailing: ElevatedButton(child: const Text('আবেদন'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ApplyPage(title: jobs[i][0])))),
    ))),
  );
}

class ApplyPage extends StatelessWidget {
  final String title;
  const ApplyPage({super.key, required this.title});
  @override
  Widget build(BuildContext context) { final n = TextEditingController(); final p = TextEditingController(); return Scaffold(
    appBar: AppBar(title: const Text('চাকরির আবেদন')),
    body: ListView(padding: const EdgeInsets.all(16), children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 16),
      TextField(controller: n, decoration: const InputDecoration(labelText: 'আপনার নাম', border: OutlineInputBorder())), const SizedBox(height: 12),
      TextField(controller: p, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'মোবাইল নম্বর', border: OutlineInputBorder())), const SizedBox(height: 16),
      ElevatedButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ডেমো আবেদন গ্রহণ করা হয়েছে'))), child: const Text('আবেদন পাঠান')),
    ])); }
}

class PostJobPage extends StatelessWidget {
  const PostJobPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('চাকরি প্রকাশ করুন')), body: ListView(padding: const EdgeInsets.all(16), children: [
    const TextField(decoration: InputDecoration(labelText: 'চাকরির নাম', border: OutlineInputBorder())), const SizedBox(height: 12),
    const TextField(decoration: InputDecoration(labelText: 'কাজের স্থান', border: OutlineInputBorder())), const SizedBox(height: 12),
    const TextField(decoration: InputDecoration(labelText: 'বেতন', border: OutlineInputBorder())), const SizedBox(height: 16),
    ElevatedButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ডেমো চাকরির তথ্য সংরক্ষণ হয়েছে'))), child: const Text('চাকরি প্রকাশ করুন')),
  ]));
}

class AboutPage extends StatelessWidget { const AboutPage({super.key}); @override Widget build(BuildContext c) => const Scaffold(appBar: null, body: Padding(padding: EdgeInsets.all(20), child: Text('Driver Bangladesh\n\nএটি AR ছাড়া তৈরি একটি প্রাথমিক ডেমো অ্যাপ। বাস্তব অনলাইন ডাটাবেজ ও লগইন পরবর্তীতে যুক্ত করতে হবে।', style: TextStyle(fontSize: 18)))); }
